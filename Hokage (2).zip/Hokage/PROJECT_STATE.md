# Hokage Project State

> [!IMPORTANT]
> For detailed historical context, architectural principles, and session continuity for AI agents, please refer to the canonical long-term memory document: [Memory.md](file:///c:/Users/anant/OneDrive/Documents/AI%20PROJECT/AI%20COMMAND%20CENTRE/Hokage/Memory.md).
## 1. Current Architecture Diagram

```mermaid
graph TD
    User([User CLI]) -->|Query| Router[Hokage Router]
    Router -->|Query| Orch[Hokage Orchestrator]
    
    subgraph Research Phase
        Orch -->|Invoke| RBot[ResearchBot]
        RBot -->|Fetch| DSource[DummyResearchSource]
        DSource -->|Findings| RBot
        RBot -->|Return| Report((ResearchReport))
    end
    
    subgraph Strategy Phase
        Orch -->|Pass Report| SBot[StrategyBot]
        SBot -->|Delegate| HGen[HeuristicStrategyGenerator]
        HGen -->|Parse| Report
        HGen -->|Generate| Proposal((StrategyProposal))
        SBot -->|Return| Proposal
    end
    
    Proposal -.->|Display| User
```

## 2. All Completed Phases

- **Foundation Phase**: Set up Git, GitHub, Obsidian, and basic project structure.
- **Research Bot Implementation**: Designed pure models, interfaces, and a functional bot to query sources and synthesize findings into a `ResearchReport`.
- **Hokage Commander MVP**: Implemented the core orchestrator, command router, and CLI interface to run the initial pipeline end-to-end.
- **StrategyBot Architectural Upgrade**: Refactored `StrategyBot` to use clean architecture, decoupling the generation logic into a `StrategyGenerator` and adding provenance tracking.
- **Execution Bot (Paper Trading)**: Implemented complete simulated trading loop, fill-simulation, local persistence, command router updates (`trade` command), and robust unit & integration tests.

## 3. Current File Structure

```text
Hokage/
├── pyproject.toml
├── PROJECT_STATE.md
├── PROJECT_STATUS.md
├── README.md
├── Mission.md
├── Tasks.md
├── Decisions.md
├── Memory.md
├── src/
│   ├── integrations/
│   │   └── data/
│   │       └── dummy_source.py
│   ├── hokage/
│   │   ├── __init__.py
│   │   ├── main.py
│   │   ├── interface/
│   │   │   ├── __init__.py
│   │   │   └── cli.py
│   │   ├── orchestrator/
│   │   │   ├── __init__.py
│   │   │   └── pipeline.py
│   │   └── router/
│   │       ├── __init__.py
│   │       └── command_router.py
│   └── bots/
│       ├── research/
│       │   ├── __init__.py
│       │   ├── interfaces.py
│       │   ├── models.py
│       │   ├── research_bot.py
│       │   └── README.md
│       ├── strategy/
│       │   ├── generators.py
│       │   ├── interfaces.py
│       │   ├── models.py
│       │   ├── strategy_bot.py
│       │   └── README.md
│       ├── backtest/
│       ├── execution/
│       ├── improvement/
│       ├── portfolio/
│       └── risk/
```

## 4. Existing Domain Models

- **`ResearchQuery`**: Represents a user's natural language research request.
- **`SourceReference`**: Metadata identifying where intelligence was sourced from.
- **`ResearchFinding`**: A single piece of intelligence collected from sources.
- **`ResearchReport`**: The structured output of the Research Bot containing a synthesized executive summary.
- **`StrategyProposal`**: Output produced by Strategy Bot detailing actionable market rules (entry, exit, stop loss) with provenance tracking.

## 5. Pending Domain Models

- **`MarketAssessment`**: To structure the raw text analysis prior to strategy formulation (trend, sentiment, volatility).
- **`TradeIdea`**: A precursor to a full `StrategyProposal`, representing a basic hypothesis (e.g., "Long EUR/USD momentum").
- **`RiskProfile`**: A structured risk object (`max_drawdown_pct`, `r_multiple`) rather than arbitrary string rules, necessary for `BacktestBot` and `RiskBot`.
- **`Signal`**: Discrete machine-readable commands (timestamp, asset, direction, magnitude) consumed by `ExecutionBot`.

## 6. Current Technical Debt

- **Dummy Integration**: `DummyResearchSource` is currently hardcoding responses instead of communicating with live market or news APIs.
- **Heuristic Generation Limitations**: `HeuristicStrategyGenerator` uses brittle keyword matching (e.g., searching for "volatility" in text) to construct rules, lacking deep semantic understanding.
- **Primitive Routing**: `CommandRouter` uses basic string matching (`startswith("research ")`) instead of NLP-based intent classification.
- **No Persistence**: Report saving is currently bypassed (`persist=False` in the pipeline).

## 7. Architectural Decisions Made Today

1. **Centralized Commander**: Established `src/hokage` as the sole entry point and user interface, hiding bot interactions behind the `HokageOrchestrator`.
2. **Dependency Injection**: Modified bots to accept their primary logical engines via constructor injection (e.g., `StrategyGenerator`) rather than hardcoding business logic inside the bots.
3. **No Direct User Communication**: Enforced the rule that specialist bots return data objects to Hokage, and Hokage formats the CLI display.

## 8. Why StrategyGenerator Was Introduced

`StrategyGenerator` was introduced to adhere to the Dependency Inversion Principle. Placing generative business logic (like heuristic parsing or LLM prompting) directly inside `StrategyBot` would tightly couple the bot to a specific generation technology. By defining a `StrategyGenerator` protocol, `StrategyBot` becomes an orchestrator of its own domain. We can seamlessly swap the temporary `HeuristicStrategyGenerator` for an `LLMStrategyGenerator` in the future without touching `StrategyBot`'s code.

## 9. Why Provenance Tracking Was Added

The `sources_cited` attribute was added to `StrategyProposal` so that every trading rule or strategy decision can be traced back to the specific research sources that influenced it. In an AI-driven trading system, interpretability and auditability are critical; if a strategy performs poorly in backtesting, we must be able to track the failure back to the specific piece of intelligence or API that generated the flawed assumption.

## 10. Exact Next Implementation Priority

The exact next implementation priority is the **Backtest Bot**. 
With the pipeline currently capable of converting a user query into a structured `StrategyProposal`, the system immediately needs the ability to validate these rules against historical data to ensure they are viable before handing them off to the Risk and Execution stages.

18-06-2026

ExecutionBot Phase 1 Completed

Architecture Decision:
Portfolio and Risk Foundation must be built before Backtest Bot.

Approved Modification:
Account supports multiple positions per market.

Next Milestone:
Portfolio Foundation

Pending Files:
- portfolio/models.py
- portfolio/store.py
- portfolio_bot.py
- risk/models.py
- risk/interfaces.py
- risk/rules.py
- risk_bot.py
