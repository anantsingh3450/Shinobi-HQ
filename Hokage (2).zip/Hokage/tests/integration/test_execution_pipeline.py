"""Integration tests for the end-to-end Hokage execution pipeline."""
from __future__ import annotations

from pathlib import Path

import pytest

import hokage.orchestrator.pipeline
from hokage.orchestrator.pipeline import HokageOrchestrator
from hokage.router.command_router import CommandRouter


def test_trade_command_pipeline_integration(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    # Arrange: Redirect paper trades directory to a temporary folder
    monkeypatch.setattr(hokage.orchestrator.pipeline, "_PAPER_TRADES_DIR", tmp_path)

    orchestrator = HokageOrchestrator()
    router = CommandRouter(orchestrator)

    # Act: Process a trade command
    result = router.handle_command("trade EUR/USD macro breakout")

    # Assert
    assert isinstance(result, dict)
    assert result["market"] == "MARKET"
    assert result["direction"] in ("LONG", "SHORT")
    assert result["quantity"] > 0
    assert result["entry_price"] == 100.0  # Mock price for MARKET (default)
    assert result["simulated_value"] == result["quantity"] * result["entry_price"]
    assert result["status"] == "OPEN"
    assert result["mode"] == "PAPER"
    assert result["trade_id"]
    assert "dummy-source-v1" in result["sources_cited"]

    # Verify that the trade record was written to the temp jsonl store
    trades_file = tmp_path / "trades.jsonl"
    assert trades_file.exists()

    # Read trades file content and verify the entry
    lines = trades_file.read_text(encoding="utf-8").splitlines()
    assert len(lines) == 1


def test_research_command_does_not_persist_trades(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    # Arrange: Redirect paper trades directory to a temporary folder
    monkeypatch.setattr(hokage.orchestrator.pipeline, "_PAPER_TRADES_DIR", tmp_path)

    orchestrator = HokageOrchestrator()
    router = CommandRouter(orchestrator)

    # Act: Process a research command
    result = router.handle_command("research EUR/USD macro breakout")

    # Assert: Result is a dictionary representing the StrategyProposal
    assert isinstance(result, dict)
    assert result["market"] == "MARKET"
    assert "entry_rule" in result
    assert "exit_rule" in result

    # Verify that NO trade record was written
    trades_file = tmp_path / "trades.jsonl"
    assert not trades_file.exists()


def test_trade_command_empty_and_unknown_handling() -> None:
    orchestrator = HokageOrchestrator()
    router = CommandRouter(orchestrator)

    # Empty trade topic
    res1 = router.handle_command("trade ")
    assert "Error: Please specify a topic" in res1

    # Unknown command
    res2 = router.handle_command("unknown_command topic")
    assert "Unknown command" in res2
