"""Portfolio Bot orchestration service.

Tracks open positions, records snapshots, and updates valuations across modes.
"""
from __future__ import annotations

from bots.execution.interfaces import PriceSource
from bots.execution.models import TradeStatus
from bots.portfolio.models import Account, EquitySnapshot, Portfolio, utc_now


class PortfolioBot:
    """Orchestrates portfolio accounting, tracking positions and equity curves."""

    def __init__(self, portfolio: Portfolio) -> None:
        """Initialize with a portfolio.

        Args:
            portfolio: The tracking portfolio state object.
        """
        self._portfolio = portfolio

    @property
    def portfolio(self) -> Portfolio:
        """The portfolio state being managed."""
        return self._portfolio

    def get_account(self, mode: str) -> Account:
        """Retrieve the account corresponding to the execution mode (e.g. "PAPER").

        Args:
            mode: The execution mode (PAPER or LIVE).

        Returns:
            The Account state object.
        """
        return self._portfolio.accounts[mode]

    def update_position_prices(self, mode: str, price_source: PriceSource) -> None:
        """Update current ticker prices for all open positions in an account.

        Args:
            mode:          The execution mode.
            price_source:  Pluggable source for ticker valuations.
        """
        account = self.get_account(mode)
        for pos in list(account.positions.values()):
            if pos.status == TradeStatus.OPEN:
                price = price_source.get_price(pos.market)
                pos.update_price(price)

    def record_snapshot(self, mode: str) -> None:
        """Record a point-in-time valuation snapshot for the account's history.

        Args:
            mode: The execution mode.
        """
        account = self.get_account(mode)
        unrealized = sum(
            p.unrealized_pnl
            for p in account.positions.values()
            if p.status == TradeStatus.OPEN
        )
        snapshot = EquitySnapshot(
            timestamp=utc_now(),
            equity=account.equity,
            cash=account.cash,
            unrealized_pnl=unrealized,
            realized_pnl=account.realized_pnl,
        )
        account.equity_history.append(snapshot)
