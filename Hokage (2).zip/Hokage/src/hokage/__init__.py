"""Hokage module."""
