"""Hokage Orchestrator — drives the bot pipeline.

Wires all bots together and exposes named pipeline methods that the
CommandRouter calls. No business logic lives here.
"""
from __future__ import annotations

from pathlib import Path

from bots.execution.engine.paper_engine import PaperEngine
from bots.execution.execution_bot import ExecutionBot
from bots.execution.store.json_trade_store import JsonTradeStore
from bots.research.models import ResearchQuery
from bots.research.research_bot import ResearchBot
from bots.strategy.generators import HeuristicStrategyGenerator
from bots.strategy.strategy_bot import StrategyBot
from integrations.data.dummy_source import DummyResearchSource
from integrations.data.mock_price_source import MockPriceSource

_PAPER_TRADES_DIR = Path("data/paper_trades")


class HokageOrchestrator:
    """Core workflow engine that drives the bot pipeline."""

    def __init__(self) -> None:
        """Initialize orchestrator with all configured bots."""
        # Research phase
        self.research_bot = ResearchBot(sources=[DummyResearchSource()])

        # Strategy phase — generator injected via DI
        self.strategy_bot = StrategyBot(generator=HeuristicStrategyGenerator())

        # Execution phase — engine and store injected via DI
        self.execution_bot = ExecutionBot(
            engine=PaperEngine(price_source=MockPriceSource()),
            store=JsonTradeStore(_PAPER_TRADES_DIR),
        )

    # ------------------------------------------------------------------
    # Pipeline: Research → Strategy
    # ------------------------------------------------------------------

    def execute_research_to_strategy(self, query_text: str) -> dict:
        """Run Research → Strategy and return a formatted StrategyProposal dict.

        Preserved for backward compatibility with the existing ``research``
        command. Does not invoke ExecutionBot.

        Args:
            query_text: The natural language research query.

        Returns:
            Dictionary of StrategyProposal fields for CLI display.
        """
        query = ResearchQuery(text=query_text)
        report = self.research_bot.research(query, persist=False)
        proposal = self.strategy_bot.generate(report)

        return {
            "name": proposal.name,
            "market": proposal.market,
            "description": proposal.description,
            "entry_rule": proposal.entry_rule,
            "exit_rule": proposal.exit_rule,
            "stop_loss_rule": proposal.stop_loss_rule,
            "take_profit_rule": proposal.take_profit_rule,
            "timeframe": proposal.timeframe,
            "confidence_score": proposal.confidence_score,
            "sources_cited": ", ".join(proposal.sources_cited),
        }

    # ------------------------------------------------------------------
    # Pipeline: Research → Strategy → PaperExecution → TradeStore
    # ------------------------------------------------------------------

    def execute_paper_trade(self, query_text: str) -> dict:
        """Run the full pipeline: Research → Strategy → PaperExecution.

        Persists the resulting TradeRecord to data/paper_trades/trades.jsonl.

        Args:
            query_text: The natural language research query.

        Returns:
            Dictionary of TradeRecord fields for CLI display.
        """
        # 1. Research
        query = ResearchQuery(text=query_text)
        report = self.research_bot.research(query, persist=False)

        # 2. Strategy
        proposal = self.strategy_bot.generate(report)

        # 3. Paper execution + persistence
        trade = self.execution_bot.execute(proposal, persist=True)

        return {
            "trade_id": trade.trade_id,
            "proposal_id": trade.proposal_id,
            "market": trade.market,
            "direction": trade.direction.value,
            "quantity": trade.quantity,
            "entry_price": trade.entry_price,
            "simulated_value": trade.simulated_value,
            "status": trade.status.value,
            "mode": trade.mode.value,
            "strategy_name": trade.strategy_name,
            "sources_cited": ", ".join(trade.sources_cited),
            "executed_at": trade.executed_at.isoformat(),
        }
